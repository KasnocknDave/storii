The site we looked at (since our project is quite unique there isn't a lot to compare to):

storyteller.katharinabrunner.de/demo/start-building-right-now

The data of this test is on the screenshot.



Our performance budget:

1.5128sec on firstview

How are we gonna be faster: 
-less deferring javascript
-mobile version gets lower quality pictures

Look and feel of our project:

Since we developed a general look and feel for 'storii' last semester we are gonna keep some parts of it.
Namely the art style and the color palette. Stuff that we develop this semester will be
oriented on this style, although the website as a whole will be recreated as a mobile-first experience within a new (and better) technology.
For the feel part of our project we also prepared a small demo of the tool we will use for our page-editor,
which will be a big part of the project in general. The files are in the zip-file and the page designs are in the image-folder.